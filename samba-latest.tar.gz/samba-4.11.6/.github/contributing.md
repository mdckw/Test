## Samba is moving to GitLab
The samba project is moving to GitLab, please consider contributing there instead.
Instructions for setting up can be found at: https://wiki.samba.org/index.php/Samba_CI_on_gitlab
The GitLab repository can be found here: https://gitlab.com/samba-team/samba
